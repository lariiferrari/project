<footer class="text-center">
    <p>&copy; 2023 Meu E-commerce. Todos os direitos reservados.</p>
</footer>