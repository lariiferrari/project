<?php
$conn = mysqli_connect("localhost", "root", "", "ecommerce_db") or die("Erro ao conectar ao banco de dados");
?>